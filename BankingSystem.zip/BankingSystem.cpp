#include <iostream>
#include <vector>
#include <string>
using namespace std;

class BankAccount
{
private:
    string name;
    int accountNumber;
    double balance;
    vector<string> history;

public:
    BankAccount(string n, int acc, double bal)
    {
        name = n;
        accountNumber = acc;
        balance = bal;
        history.push_back("Account Created with Balance: " + to_string(balance));
    }

    int getAccountNumber()
    {
        return accountNumber;
    }

    void showDetails()
    {
        cout << "\n------ Account Details ------" << endl;
        cout << "Name: " << name << endl;
        cout << "Account Number: " << accountNumber << endl;
        cout << "Balance: Rs. " << balance << endl;
    }

    void deposit(double amount)
    {
        if (amount > 0)
        {
            balance += amount;
            history.push_back("Deposited Rs. " + to_string(amount));
            cout << "Deposit Successful!" << endl;
        }
        else
        {
            cout << "Invalid Amount!" << endl;
        }
    }

    void withdraw(double amount)
    {
        if (amount <= balance && amount > 0)
        {
            balance -= amount;
            history.push_back("Withdrawn Rs. " + to_string(amount));
            cout << "Withdrawal Successful!" << endl;
        }
        else
        {
            cout << "Insufficient Balance or Invalid Amount!" << endl;
        }
    }

    void showHistory()
    {
        cout << "\n----- Transaction History -----" << endl;
        for (string transaction : history)
        {
            cout << transaction << endl;
        }
    }
};

int main()
{
    vector<BankAccount> accounts;

    int choice;
    int accNo;
    string name;
    double amount;
    double initialBalance;

    while (true)
    {
        cout << "\n====== BANKING SYSTEM ======" << endl;
        cout << "1. Create Account" << endl;
        cout << "2. View Account" << endl;
        cout << "3. Deposit Money" << endl;
        cout << "4. Withdraw Money" << endl;
        cout << "5. Transaction History" << endl;
        cout << "6. Exit" << endl;
        cout << "Enter Choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            cout << "Enter Name: ";
            cin.ignore();
            getline(cin, name);

            cout << "Enter Account Number: ";
            cin >> accNo;

            cout << "Enter Initial Balance: ";
            cin >> initialBalance;

            accounts.push_back(BankAccount(name, accNo, initialBalance));
            cout << "Account Created Successfully!" << endl;
            break;

        case 2:
        {
            cout << "Enter Account Number: ";
            cin >> accNo;

            bool found = false;

            for (auto &acc : accounts)
            {
                if (acc.getAccountNumber() == accNo)
                {
                    acc.showDetails();
                    found = true;
                    break;
                }
            }

            if (!found)
                cout << "Account Not Found!" << endl;

            break;
        }

        case 3:
        {
            cout << "Enter Account Number: ";
            cin >> accNo;

            cout << "Enter Deposit Amount: ";
            cin >> amount;

            bool found = false;

            for (auto &acc : accounts)
            {
                if (acc.getAccountNumber() == accNo)
                {
                    acc.deposit(amount);
                    found = true;
                    break;
                }
            }

            if (!found)
                cout << "Account Not Found!" << endl;

            break;
        }

        case 4:
        {
            cout << "Enter Account Number: ";
            cin >> accNo;

            cout << "Enter Withdrawal Amount: ";
            cin >> amount;

            bool found = false;

            for (auto &acc : accounts)
            {
                if (acc.getAccountNumber() == accNo)
                {
                    acc.withdraw(amount);
                    found = true;
                    break;
                }
            }

            if (!found)
                cout << "Account Not Found!" << endl;

            break;
        }

        case 5:
        {
            cout << "Enter Account Number: ";
            cin >> accNo;

            bool found = false;

            for (auto &acc : accounts)
            {
                if (acc.getAccountNumber() == accNo)
                {
                    acc.showHistory();
                    found = true;
                    break;
                }
            }

            if (!found)
                cout << "Account Not Found!" << endl;

            break;
        }

        case 6:
            cout << "Thank You for Using Banking System!" << endl;
            return 0;

        default:
            cout << "Invalid Choice!" << endl;
        }
    }

    return 0;
}